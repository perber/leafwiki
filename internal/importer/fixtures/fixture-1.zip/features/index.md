# Features

This directory contains test fixtures for the zip importer. It includes a sample wiki structure with markdown files and folders to simulate a real wiki environment.

At the moment we are in the "Features" section of the wiki. You can navigate to other sections such as "Home" to explore more content.